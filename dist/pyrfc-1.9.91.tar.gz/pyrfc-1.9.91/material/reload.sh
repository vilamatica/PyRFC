pip uninstall -y pyrfc
python setup.py bdist_wheel
pip install dist/pyrfc-1.9.8-cp27-cp27m-win_amd64.whl
